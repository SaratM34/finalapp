.. -*- rst -*-

Authors
=======
This software was written and packaged by `Lev E. Givon <lev@columbia.edu>`_.

Special thanks are due to the following parties for their contributions:

- `Colin Jermain <https://github.com/cjermain>`_ - Python 3 support.
- `John Tyree <https://github.com/johntyree>`_ - support for numpy scalar 
  booleans.
- `Mehdi Sadeghi <https://github.com/mehdisadeghi>`_ - bug reports.
- `Sujoy Roy <https://github.com/tvkpz>`_ - bug reports.
- `Jose Coutinho <https://github.com/tiagocoutinho>`_ - make msgpack-numpy 
  params consistent with msgpack-python.
